from pyrogram import Client, filters
from pytgcalls import PyTgCalls, idle
from pytgcalls.types import InputStream, AudioPiped
import yt_dlp
import os

API_ID = int(os.environ.get("API_ID"))
API_HASH = os.environ.get("API_HASH")
BOT_TOKEN = os.environ.get("BOT_TOKEN")

app = Client("music_bot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)
call_py = PyTgCalls(app)

# فەرمانی پخش موزیک
@app.on_message(filters.command("play") & filters.group)
async def play(_, message):
    if len(message.command) < 2:
        await message.reply("🎵 ناوی گۆرانی بنوسە: `/play despacito`")
        return
    
    query = " ".join(message.command[1:])
    await message.reply(f"🔍 گەڕان بۆ گۆرانی: {query}")
    
    ydl_opts = {"format": "bestaudio/best", "noplaylist": True}
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(f"ytsearch:{query}", download=False)
        url = info["entries"][0]["url"]
    
    chat_id = message.chat.id
    await call_py.join_group_call(chat_id, InputStream(AudioPiped(url)))
    await message.reply("▶️ گۆرانی دەستپێکرد!")

# پخش موزیک لە چات تایبەتی
@app.on_message(filters.command("song") & filters.private)
async def song(_, message):
    if len(message.command) < 2:
        await message.reply("🎶 ناوی گۆرانی بنوسە: `/song despacito`")
        return
    
    query = " ".join(message.command[1:])
    await message.reply(f"🔍 گەڕان بۆ گۆرانی: {query}")
    
    ydl_opts = {"format": "bestaudio/best"}
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(f"ytsearch:{query}", download=True)
        file_name = ydl.prepare_filename(info["entries"][0])
    
    await message.reply_audio(file_name)
    os.remove(file_name)

call_py.start()
app.start()
idle()
